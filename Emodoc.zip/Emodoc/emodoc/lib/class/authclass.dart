import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:emodoc/screens/home-page.dart';
import 'package:emodoc/screens/login-page.dart';
import 'package:emodoc/screens/welcomescreen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class Auth {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  signUpFunction(String username, password, email, BuildContext context) async {
    print("try to signup");
    try {
      final userCredential = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(email: email, password: password);
      Map<String, dynamic> data = {
        'email': email,
        'password': password,
        'username': username,
        'moodscore': 0,
        'number': 0
      };

      await _firestore.collection('users').doc(email).set(data);
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => WelcomeScreen()));
    } catch (e) {
      if (e == 'weak-password') {
        print('The password provided is too weak.');
      } else if (e == 'email-already-in-use') {
        print('The account already exists for that email.');
      }
    }
  }

  signinFunction(String password, email, BuildContext context) async {
    try {
      UserCredential userCredential = await FirebaseAuth.instance
          .signInWithEmailAndPassword(email: email, password: password);
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => Home()));
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        print('No user found for that email.');
      } else if (e.code == 'wrong-password') {
        print('Wrong password provided for that user.');
      }
    }
  }

  signOutFunction(BuildContext context) async {
    print("Sign outttttttttttttttttt");
    try {
      await FirebaseAuth.instance.signOut();
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => LoginPage()));
    } catch (e) {
      print(e);
    }
  }
}
