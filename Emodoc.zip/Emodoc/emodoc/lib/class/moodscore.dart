import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class MoodScore {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final mail = FirebaseAuth.instance.currentUser!.email;

  moodScoreUpdate(int moodScore, int num) async {
    print(moodScore);
    int temp = 0;
    int score = 0;
    try {
      await _firestore.collection('users').doc(mail).get().then((value) {
        temp = value['moodscore'];
        print(temp);
        score = (moodScore + temp / 2).toInt();
        print('scoreeeeeeeeeee' + score.toString());
      });
      await _firestore
          .collection('users')
          .doc(mail)
          .update({'moodscore': score, 'number': num});
    } catch (e) {}
  }

  Future<Map> getmoodScore() async {
    int temp = 0, num = 0;
    try {
      await _firestore.collection('users').doc(mail).get().then((value) {
        temp = value['moodscore'];
        num = value['number'];
      });
    } catch (e) {}

    return {'score': temp, 'num': num};
  }
}
