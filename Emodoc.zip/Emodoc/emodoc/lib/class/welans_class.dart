import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:emodoc/screens/home-page.dart';
import 'package:flutter/material.dart';

class WelAns {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  uploadAnsDB(
      Map<String, dynamic> ansdata, String frnd, BuildContext context) async {
    Map<String, dynamic> data = {'frndmail': frnd};
    data.addAll(ansdata);
    await _firestore.collection('users').doc('mail').set(data);
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => const Home()));
  }
}
