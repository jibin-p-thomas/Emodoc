import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class UserDataDB {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  userData(String mail, username, password) async {
    Map<String, dynamic> data = {
      'email': mail,
      'password': password,
      'username': username,
    };
    try {
      await _firestore.collection('users').doc('mail').set(data);
    } catch (e) {}
  }
}
