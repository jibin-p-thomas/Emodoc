import 'package:emodoc/screens/home-page.dart';
import 'package:emodoc/screens/quizscrn.dart';
import 'package:flutter/material.dart';

class NavBar extends StatefulWidget {
  int index;
  NavBar({Key? key, required this.index}) : super(key: key);

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: widget.index,
      items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.home),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.account_circle),
          label: 'Quiz',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.account_circle),
          label: 'Home',
        ),
      ],
      onTap: (index) {
        switch (index) {
          case 0:
            {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const Home()));
              break;
            }
          case 1:
            {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const QuizScreen()));
              break;
            }
          case 2:
            {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const Home()));
              break;
            }
        }
      },
    );
  }
}
