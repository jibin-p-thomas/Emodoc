import 'package:emodoc/class/welans_class.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({Key? key}) : super(key: key);

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  PageController _pageController = PageController();
  TextEditingController frndsemail = TextEditingController();
  Map<String, dynamic> welans = {
    'How are you': '',
    'How are yeewcecweou': '',
    'How arewewewce you': ''
  };
  String frndmail = "";

  List<Map> pages = [
    {'0': 'g'},
    {
      'ques': 'How are you',
      'a': 'fine',
      'b': 'good',
      'c': 'nice',
      'd': 'ooooo',
      'isSel': false,
      'selindex': 0
    },
    {
      'ques': 'How are yeewcecweou',
      'a': 'fine',
      'b': 'good',
      'c': 'nice',
      'd': 'ooooo',
      'isSel': false,
      'selindex': 0
    },
    {
      'ques': 'How arewewewce you',
      'a': 'fine',
      'b': 'good',
      'c': 'nice',
      'd': 'ooooo',
      'isSel': false,
      'selindex': 0
    }
  ];
  bool clia = false;
  bool clib = false;

  bool clic = false;
  bool clid = false;
  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: PageView.builder(
        controller: _pageController,
        itemCount: pages.length,
        itemBuilder: (context, index) {
          bool isto = (index == pages.length - 1) ? true : false;
          bool issel = false;

          return Container(
              height: height,
              decoration: const BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                      colors: [Colors.purple, Colors.blue])),
              child: (index == 0)
                  ? Column(
                      children: [
                        SizedBox(
                          height: height / 20,
                        ),
                        Text(
                          'Enter your frnds email',
                          style: TextStyle(fontSize: width / 12),
                        ),
                        SizedBox(
                          height: height / 20,
                        ),
                        Padding(
                          padding: const EdgeInsets.all(11.0),
                          child: TextFormField(
                            style: TextStyle(
                                fontSize: width / 20, color: Colors.white),
                            controller: frndsemail,
                            decoration: InputDecoration(
                              fillColor: Colors.grey.withOpacity(0.25),
                              hoverColor: Colors.grey.shade200,
                              filled: true,
                              focusColor: Colors.grey.shade200,
                              prefixIcon: Icon(
                                FontAwesomeIcons.solidEnvelope,
                                color: Colors.white,
                              ),
                              border: OutlineInputBorder(
                                borderRadius: const BorderRadius.all(
                                  const Radius.circular(10.0),
                                ),
                              ),
                              labelText: 'Friends Email',
                              hintText: 'Enter Your Friend Email',
                              hintStyle: TextStyle(color: Colors.white),
                              labelStyle: TextStyle(color: Colors.white),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: height / 20,
                        ),
                        ElevatedButton(
                            onPressed: () {
                              print(isto);
                              int num = index + 1;
                              if (_pageController.hasClients && isto == false) {
                                _pageController.animateToPage(
                                  num,
                                  duration: const Duration(milliseconds: 400),
                                  curve: Curves.easeInOut,
                                );
                                if (index == 0) {
                                  frndmail = frndsemail.text.toString();
                                }
                              }
                            },
                            child: Text((isto) ? 'Finish' : 'Next',
                                style: TextStyle(fontSize: width / 15)))
                      ],
                    )
                  : Column(
                      children: [
                        SizedBox(
                          height: height / 20,
                        ),
                        Text(
                          pages[index]['ques'],
                          style: TextStyle(fontSize: width / 9),
                        ),
                        SizedBox(
                          height: height / 20,
                        ),
                        (clia)
                            ? curvedans(pages[index]['a'], width, height, true,
                                1, index)
                            : curvedans(pages[index]['a'], width, height, false,
                                1, index),
                        SizedBox(
                          height: height / 20,
                        ),
                        (clib)
                            ? curvedans(pages[index]['b'], width, height, true,
                                2, index)
                            : curvedans(pages[index]['b'], width, height, false,
                                2, index),
                        SizedBox(
                          height: height / 20,
                        ),
                        (clic)
                            ? curvedans(pages[index]['c'], width, height, true,
                                3, index)
                            : curvedans(pages[index]['c'], width, height, false,
                                3, index),
                        SizedBox(
                          height: height / 20,
                        ),
                        (clid)
                            ? curvedans(pages[index]['d'], width, height, true,
                                4, index)
                            : curvedans(pages[index]['d'], width, height, false,
                                4, index),
                        SizedBox(
                          height: height / 20,
                        ),
                        ElevatedButton(
                            onPressed: () {
                              print(isto);
                              int num = index + 1;
                              if (_pageController.hasClients && isto == false) {
                                setState(() {
                                  clia = false;
                                  clib = false;
                                  clic = false;
                                  clid = false;
                                });

                                _pageController.animateToPage(
                                  num,
                                  duration: const Duration(milliseconds: 400),
                                  curve: Curves.easeInOut,
                                );
                              }
                              if (isto) {
                                print(welans);
                                print(frndmail);

                                WelAns().uploadAnsDB(welans, frndmail, context);
                              }
                            },
                            child: Text((isto) ? 'Finish' : 'Next',
                                style: TextStyle(fontSize: width / 15)))
                      ],
                    ));
        },
      ),
    );
  }

  Widget curvedans(
      String data, double width, height, bool isselected, int index, curindex) {
    return InkWell(
      onTap: () {
        welans.update(pages[curindex]['ques'], (value) => data);
        print(welans);

        if (index == 1) {
          setState(() {
            clia = true;
            clib = false;
            clic = false;
            clid = false;
          });
        }
        if (index == 2) {
          setState(() {
            clib = true;
            clia = false;
            clic = false;
            clid = false;
          });
        }
        if (index == 3) {
          setState(() {
            clic = true;
            clib = false;
            clia = false;
            clid = false;
          });
        }
        if (index == 4) {
          setState(() {
            clid = true;
            clib = false;
            clic = false;
            clia = false;
          });
        }
      },
      child: Container(
        height: height / 20,
        width: width / 1.1,
        decoration: BoxDecoration(
          color: Colors.white,
          border:
              (isselected) ? Border.all(color: Colors.green, width: 5) : null,
          borderRadius: const BorderRadius.only(
              topRight: Radius.circular(40.0),
              bottomRight: Radius.circular(40.0),
              topLeft: Radius.circular(40.0),
              bottomLeft: Radius.circular(40.0)),
        ),
        child:
            Center(child: Text(data, style: TextStyle(fontSize: width / 15))),
      ),
    );
  }
}

class QuesFullPage extends StatefulWidget {
  Map data;
  QuesFullPage({Key? key, required this.data}) : super(key: key);

  @override
  State<QuesFullPage> createState() => _QuesFullPageState();
}

class _QuesFullPageState extends State<QuesFullPage> {
  bool issel = false;
  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    return Container(
        height: height,
        decoration: const BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
                colors: [Colors.purple, Colors.blue])),
        child: Column(
          children: [
            SizedBox(
              height: height / 20,
            ),
            Text(
              widget.data['ques'],
              style: TextStyle(fontSize: width / 9),
            ),
            SizedBox(
              height: height / 20,
            ),
            curvedans(widget.data['a'], width, height, issel),
            SizedBox(
              height: height / 20,
            ),
            curvedans(widget.data['b'], width, height, issel),
            SizedBox(
              height: height / 20,
            ),
            curvedans(widget.data['c'], width, height, issel),
            SizedBox(
              height: height / 20,
            ),
            curvedans(widget.data['d'], width, height, issel),
            SizedBox(
              height: height / 20,
            ),
            ElevatedButton(
                onPressed: () {},
                child: Text('Next', style: TextStyle(fontSize: width / 15)))
          ],
        ));
  }

  Widget curvedans(String data, double width, height, bool isselected) {
    return InkWell(
      onTap: () {},
      child: Container(
        height: height / 20,
        width: width / 1.1,
        decoration: BoxDecoration(
          color: Colors.white,
          border:
              (isselected) ? Border.all(color: Colors.green, width: 5) : null,
          borderRadius: const BorderRadius.only(
              topRight: Radius.circular(40.0),
              bottomRight: Radius.circular(40.0),
              topLeft: Radius.circular(40.0),
              bottomLeft: Radius.circular(40.0)),
        ),
        child:
            Center(child: Text(data, style: TextStyle(fontSize: width / 15))),
      ),
    );
  }
}
