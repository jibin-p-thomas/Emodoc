import 'package:emodoc/class/authclass.dart';
import 'package:emodoc/widgets/background-image.dart';
import 'package:flutter/material.dart';

import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class SignupPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    TextEditingController username = TextEditingController();
    TextEditingController password = TextEditingController();
    TextEditingController useremail = TextEditingController();

    String name = "";
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    return Stack(
      children: [
        BackgroundImage(),
        Scaffold(
          backgroundColor: Colors.transparent,
          body: SingleChildScrollView(
            child: SafeArea(
              child: Column(
                children: [
                  Container(
                    height: 150,
                    child: Center(
                      child: Text(
                        'Signup',
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 100,
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 40),
                    child: Column(
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            TextFormField(
                              style: TextStyle(
                                  fontSize: width / 20, color: Colors.white),
                              controller: username,
                              decoration: InputDecoration(
                                fillColor: Colors.grey.withOpacity(0.25),
                                hoverColor: Colors.grey.shade200,
                                filled: true,
                                focusColor: Colors.grey.shade200,
                                prefixIcon: const Icon(
                                  FontAwesomeIcons.userAlt,
                                  color: Colors.white,
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: const BorderRadius.all(
                                    const Radius.circular(10.0),
                                  ),
                                ),
                                labelText: 'User Name',
                                hintText: 'Enter Your Name',
                                hintStyle: TextStyle(color: Colors.white),
                                labelStyle: TextStyle(color: Colors.white),
                              ),

                              /* icon: FontAwesomeIcons.userAlt,
                              hint: 'Last Name',
                              inputType: TextInputType.text,
                              //inputAction: TextInputAction.next,*/
                            ),
                            TextFormField(
                              style: TextStyle(
                                  fontSize: width / 20, color: Colors.white),
                              controller: useremail,
                              decoration: InputDecoration(
                                fillColor: Colors.grey.withOpacity(0.25),
                                hoverColor: Colors.grey.shade200,
                                filled: true,
                                focusColor: Colors.grey.shade200,
                                prefixIcon: Icon(
                                  FontAwesomeIcons.solidEnvelope,
                                  color: Colors.white,
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: const BorderRadius.all(
                                    const Radius.circular(10.0),
                                  ),
                                ),
                                labelText: 'Email',
                                hintText: 'Enter Your Email',
                                hintStyle: TextStyle(color: Colors.white),
                                labelStyle: TextStyle(color: Colors.white),
                              ),
                            ),
                            TextFormField(
                              style: TextStyle(
                                  fontSize: width / 20, color: Colors.white),
                              obscureText: true,
                              controller: password,
                              decoration: InputDecoration(
                                fillColor: Colors.grey.withOpacity(0.25),
                                hoverColor: Colors.grey.shade200,
                                filled: true,
                                focusColor: Colors.grey.shade200,
                                prefixIcon: Icon(
                                  FontAwesomeIcons.lock,
                                  color: Colors.white,
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: const BorderRadius.all(
                                    const Radius.circular(10.0),
                                  ),
                                ),
                                labelText: 'Password',
                                hintText: 'Enter Your Password',
                                hintStyle: TextStyle(color: Colors.white),
                                labelStyle: TextStyle(color: Colors.white),
                              ),
                            ),
                          ],
                        ),
                        Column(
                          children: [
                            SizedBox(
                              height: 100,
                            ),
                            ElevatedButton(
                                onPressed: () {
                                  print("Hello ");
                                  Auth().signUpFunction(
                                      username.text.toString(),
                                      password.text.toString(),
                                      useremail.text.toString(),
                                      context);
                                },
                                /*child: RoundedButton(*/
                                child: const Text("Signup")),
                            SizedBox(
                              height: 80,
                            ),
                            SizedBox(
                              height: 30,
                            ),
                          ],
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
