import 'package:emodoc/class/authclass.dart';
import 'package:emodoc/screens/signup-page.dart';
import 'package:emodoc/widgets/background-image.dart';
import 'package:flutter/material.dart';

import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    TextEditingController useremail = TextEditingController();
    TextEditingController password = TextEditingController();
    String name = "";
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.height;
    return Stack(
      children: [
        BackgroundImage(),
        Scaffold(
          backgroundColor: Colors.transparent,
          body: SingleChildScrollView(
            child: SafeArea(
              child: Column(
                children: [
                  Container(
                    height: 150,
                    child: Center(
                      child: Text(
                        'em😀doc',
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 100,
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 40),
                    child: Column(
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            TextFormField(
                              style: TextStyle(
                                  fontSize: width / 40, color: Colors.white),
                              controller: useremail,
                              decoration: InputDecoration(
                                fillColor: Colors.grey.withOpacity(0.25),
                                hoverColor: Colors.grey.shade200,
                                filled: true,
                                focusColor: Colors.grey.shade200,
                                prefixIcon: Icon(
                                  FontAwesomeIcons.solidEnvelope,
                                  color: Colors.white,
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: const BorderRadius.all(
                                    const Radius.circular(10.0),
                                  ),
                                ),
                                labelText: 'Email',
                                hintText: 'Enter Your Email',
                                hintStyle: TextStyle(color: Colors.white),
                                labelStyle: TextStyle(color: Colors.white),
                              ),
                            ),
                            TextFormField(
                              style: TextStyle(
                                  fontSize: width / 40, color: Colors.white),
                              obscureText: true,
                              controller: password,
                              decoration: InputDecoration(
                                fillColor: Colors.grey.withOpacity(0.25),
                                hoverColor: Colors.grey.shade200,
                                filled: true,
                                focusColor: Colors.grey.shade200,
                                prefixIcon: Icon(
                                  FontAwesomeIcons.lock,
                                  color: Colors.white,
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: const BorderRadius.all(
                                    const Radius.circular(10.0),
                                  ),
                                ),
                                labelText: 'Password',
                                hintText: 'Enter Your Password',
                                hintStyle: TextStyle(color: Colors.white),
                                labelStyle: TextStyle(color: Colors.white),
                              ),
                            ),
                            Text('Forgot Password?',
                                style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.white,
                                    height: 2)),
                          ],
                        ),
                        Column(
                          children: [
                            SizedBox(
                              height: 100,
                            ),
                            SizedBox(
                              width: width / 7,
                              child: ElevatedButton(
                                  onPressed: () {
                                    print("Hello ");
                                    Auth().signinFunction(
                                        password.text.toString(),
                                        useremail.text.toString(),
                                        context);
                                  },
                                  /*child: RoundedButton(*/
                                  child: const Text("Signin")),
                            ),
                            SizedBox(
                              height: 50,
                            ),
                            InkWell(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => SignupPage()),
                                  );
                                },
                                child: Container(
                                  decoration: BoxDecoration(
                                      border: Border(
                                    bottom: BorderSide(
                                        color: Colors.white, width: 1),
                                  )),
                                  child: const Text('CreateNewAccount',
                                      style: TextStyle(
                                          fontSize: 20,
                                          color: Colors.white,
                                          height: 2)),
                                )),
                            SizedBox(
                              height: 30,
                            ),
                          ],
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
