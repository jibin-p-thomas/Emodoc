import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class AudioPlayerWidget extends StatefulWidget {
  String url, img;
  AudioPlayerWidget({Key? key, required this.img, required this.url})
      : super(key: key);

  @override
  State<AudioPlayerWidget> createState() => _AudioPlayerWidgetState();
}

class _AudioPlayerWidgetState extends State<AudioPlayerWidget> {
  AudioPlayer audioPlayer = AudioPlayer();
  AudioCache audioCache = AudioCache();
  AudioPlayer advancedPlayer = AudioPlayer();
  bool isplay = false;
  String url =
      'https://firebasestorage.googleapis.com/v0/b/emodoc-8de63.appspot.com/o/songs%2Fsong1.mp3?alt=media&token=bc3f76b7-db1f-4778-957f-d973e16fdeb5';
  play() async {
    int result = await audioPlayer.play(url);

    if (result == 1) {
      print("sucess");
      setState(() {
        isplay = true;
      });
    }
  }

  pause() async {
    int result = await audioPlayer.pause();
    if (result == 1) {
      print("sucess");
      setState(() {
        isplay = false;
      });
    }
  }

  @override
  void initState() {
    url = widget.url;
    play();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: Text('Music Player'),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: width,
          height: height,
          decoration: const BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  colors: [Colors.purple, Colors.blue])),
          child: Column(
            children: [
              Card(
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(
                    Radius.circular(16.0),
                  ),
                ),
                child: Image.asset(
                  widget.img,
                  fit: BoxFit.contain,
                  width: width / 1.4,
                  height: height / 2,
                ),
              ),
              ElevatedButton(
                  onPressed: () {
                    isplay ? pause() : play();
                  },
                  child: Text(isplay ? "pause" : 'Play')),
            ],
          ),
        ),
      ),
    );
  }
}
