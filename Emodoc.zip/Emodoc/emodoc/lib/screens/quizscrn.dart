import 'package:emodoc/screens/scorepage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class QuizScreen extends StatefulWidget {
  const QuizScreen({Key? key}) : super(key: key);

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  List<Map> quiz = [
    {
      'ques': 'How are you',
      'a': false,
      'b': false,
      'c': false,
      'd': false,
      'point': 0
    },
    {
      'ques': 'How are yeewcecweou',
      'a': false,
      'b': false,
      'c': false,
      'd': false,
      'point': 0
    },
    {
      'ques': 'How arewewewce you',
      'a': false,
      'b': false,
      'c': false,
      'd': false,
      'point': 0
    },
    {
      'ques': 'How are you',
      'a': false,
      'b': false,
      'c': false,
      'd': false,
      'point': 0
    },
    {
      'ques': 'How are yeewcecweou',
      'a': false,
      'b': false,
      'c': false,
      'd': false,
      'point': 0
    },
    {
      'ques': 'How arewewewce you',
      'a': false,
      'b': false,
      'c': false,
      'd': false,
      'point': 0
    },
    {
      'ques': 'How are you',
      'a': false,
      'b': false,
      'c': false,
      'd': false,
      'point': 0
    },
    {
      'ques': 'How are yeewcecweou',
      'a': false,
      'b': false,
      'c': false,
      'd': false,
      'point': 0
    },
    {
      'ques': 'How arewewewce you',
      'a': false,
      'b': false,
      'c': false,
      'd': false,
      'point': 0
    },
    /* {
      'ques': 'How are you',
      'a': false,
      'b': false,
      'c': false,
      'd': false,
      'point': 0
    },
    {
      'ques': 'How are yeewcecweou',
      'a': false,
      'b': false,
      'c': false,
      'd': false,
      'point': 0
    },
    {
      'ques': 'How arewewewce you',
      'a': false,
      'b': false,
      'c': false,
      'd': false,
      'point': 0
    },*/
    {'hhj': 'gy'}
  ];
  int score = 0;
  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: Text('Quiz'),
      ),
      body: Container(
        height: height,
        decoration: const BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
                colors: [Colors.purple, Colors.blue])),
        child: ListView.builder(
            itemCount: quiz.length,
            itemBuilder: (context, index) {
              return (index == quiz.length - 1)
                  ? ElevatedButton(
                      onPressed: () {
                        int len = quiz.length;

                        int totalscore = 0;

                        for (int i = 0; i < len - 1; i++) {
                          totalscore = (totalscore + quiz[i]['point']).toInt();
                        }
                        print(totalscore);
                        print(len - 1);
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ScorePage(
                                      score: totalscore,
                                      number: len - 1,
                                    )));
                      },
                      child: Text('Next'))
                  : Card(
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(16.0),
                        ),
                      ),
                      child: Column(
                        children: [
                          SizedBox(
                            height: height / 60,
                          ),
                          Text(
                            quiz[index]['ques'],
                            style: TextStyle(fontSize: width / 17),
                          ),
                          SizedBox(
                            height: height / 40,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              InkWell(
                                onTap: () {
                                  setState(() {
                                    quiz[index]['a'] = true;
                                    quiz[index]['b'] = false;
                                    quiz[index]['c'] = false;
                                    quiz[index]['d'] = false;
                                    quiz[index]['point'] = 4;
                                  });
                                },
                                child: Container(
                                  width: width / 6,
                                  height: height / 15,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: (quiz[index]['a'])
                                        ? Border.all(
                                            color: Colors.green, width: 5)
                                        : null,
                                    borderRadius: const BorderRadius.only(
                                        topRight: Radius.circular(40.0),
                                        bottomRight: Radius.circular(40.0),
                                        topLeft: Radius.circular(40.0),
                                        bottomLeft: Radius.circular(40.0)),
                                  ),
                                  child: Image.asset(
                                    'assets/images/smile.png',
                                    width: width / 7,
                                    height: height / 16,
                                  ),
                                ),
                              ),
                              InkWell(
                                onTap: () {
                                  setState(() {
                                    quiz[index]['a'] = false;
                                    quiz[index]['b'] = true;
                                    quiz[index]['c'] = false;
                                    quiz[index]['d'] = false;
                                    quiz[index]['point'] = 3;
                                  });
                                },
                                child: Container(
                                  width: width / 6,
                                  height: height / 15,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: (quiz[index]['b'])
                                        ? Border.all(
                                            color: Colors.green, width: 5)
                                        : null,
                                    borderRadius: const BorderRadius.only(
                                        topRight: Radius.circular(40.0),
                                        bottomRight: Radius.circular(40.0),
                                        topLeft: Radius.circular(40.0),
                                        bottomLeft: Radius.circular(40.0)),
                                  ),
                                  child: Image.asset(
                                    'assets/images/netural.png',
                                    width: width / 8,
                                    height: height / 19,
                                  ),
                                ),
                              ),
                              InkWell(
                                onTap: () {
                                  setState(() {
                                    quiz[index]['a'] = false;
                                    quiz[index]['b'] = false;
                                    quiz[index]['c'] = true;
                                    quiz[index]['d'] = false;
                                    quiz[index]['point'] = 2;
                                  });
                                },
                                child: Container(
                                  width: width / 6,
                                  height: height / 15,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: (quiz[index]['c'])
                                        ? Border.all(
                                            color: Colors.green, width: 5)
                                        : null,
                                    borderRadius: const BorderRadius.only(
                                        topRight: Radius.circular(40.0),
                                        bottomRight: Radius.circular(40.0),
                                        topLeft: Radius.circular(40.0),
                                        bottomLeft: Radius.circular(40.0)),
                                  ),
                                  child: Image.asset(
                                    'assets/images/sad.png',
                                    width: width / 8,
                                    height: height / 19,
                                  ),
                                ),
                              ),
                              InkWell(
                                onTap: () {
                                  setState(() {
                                    quiz[index]['a'] = false;
                                    quiz[index]['b'] = false;
                                    quiz[index]['c'] = false;
                                    quiz[index]['d'] = true;
                                    quiz[index]['point'] = 1;
                                  });
                                },
                                child: Container(
                                  width: width / 6,
                                  height: height / 15,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: (quiz[index]['d'])
                                        ? Border.all(
                                            color: Colors.green, width: 5)
                                        : null,
                                    borderRadius: const BorderRadius.only(
                                        topRight: Radius.circular(40.0),
                                        bottomRight: Radius.circular(40.0),
                                        topLeft: Radius.circular(40.0),
                                        bottomLeft: Radius.circular(40.0)),
                                  ),
                                  child: Image.asset(
                                    'assets/images/angry.png',
                                    width: width / 9,
                                    height: height / 20,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: height / 60,
                          ),
                        ],
                      ),
                    );
            }),
      ),
    );
  }
}
