import 'package:emodoc/class/moodscore.dart';
import 'package:emodoc/screens/audioplayer.dart';
import 'package:emodoc/widgets/navbar.dart';
import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int moodscore = 0;
  int score = 0;
  int num = 0;
  String moodstring = "Happy !";
  String img = 'assets/images/smile.png';
  List happyquote = [
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'}
  ];
  List normalquote = [
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'}
  ];
  List sadquote = [
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'}
  ];
  List angryquote = [
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'}
  ];
  //songs list
  List happysongs = [
    {
      'image': 'assets/images/sadquote1.jpg',
      'name': 'stay happy',
      'url':
          'https://firebasestorage.googleapis.com/v0/b/emodoc-8de63.appspot.com/o/songs%2Fsong1.mp3?alt=media&token=bc3f76b7-db1f-4778-957f-d973e16fdeb5',
    },
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'}
  ];
  List normalsongs = [
    {
      'image': 'assets/images/sadquote1.jpg',
      'name': 'stay happy',
      'url':
          'https://firebasestorage.googleapis.com/v0/b/emodoc-8de63.appspot.com/o/songs%2Fsong1.mp3?alt=media&token=bc3f76b7-db1f-4778-957f-d973e16fdeb5',
    },
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'}
  ];
  List sadsongs = [
    {
      'image': 'assets/images/sadquote1.jpg',
      'name': 'stay happy',
      'url':
          'https://firebasestorage.googleapis.com/v0/b/emodoc-8de63.appspot.com/o/songs%2Fsong1.mp3?alt=media&token=bc3f76b7-db1f-4778-957f-d973e16fdeb5',
    },
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'}
  ];
  List angrysongs = [
    {
      'image': 'assets/images/sadquote1.jpg',
      'name': 'stay happy',
      'url':
          'https://firebasestorage.googleapis.com/v0/b/emodoc-8de63.appspot.com/o/songs%2Fsong1.mp3?alt=media&token=bc3f76b7-db1f-4778-957f-d973e16fdeb5',
    },
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'},
    {'image': 'assets/images/sadquote1.jpg', 'quote': 'stay happy'}
  ];
  List quote = [];
  List songs = [];

  getScore() async {
    await MoodScore().getmoodScore().then((value) {
      score = value['score'];
      print(value['score']);
      num = value['num'];
    });
    scorecal();
  }

  scorecal() {
    setState(() {
      moodscore = score;
      if (moodscore == 4) {
        img = 'assets/images/smile.png';
        moodstring = "Happy !";
        quote = happyquote;
        songs = happysongs;
      } else if (moodscore == 3) {
        img = 'assets/images/netural.png';
        moodstring = "Normal !";
        quote = normalquote;
        songs = normalsongs;
      } else if (moodscore == 2) {
        img = 'assets/images/sad.png';
        moodstring = "Sad !";
        quote = sadquote;
        songs = sadsongs;
      } else if (moodscore == 1) {
        img = 'assets/images/angry.png';
        moodstring = "Angry !";
        quote = angryquote;
        songs = angrysongs;
      }
    });
  }

  @override
  void initState() {
    getScore();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: const Text("Home"),
        actions: [IconButton(onPressed: () {}, icon: Icon(Icons.logout))],
      ),
      body: SingleChildScrollView(
          child: Container(
        decoration: const BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
                colors: [Colors.purple, Colors.blue])),
        child: Column(
          children: [
            Center(
              child: Card(
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(
                    Radius.circular(16.0),
                  ),
                ),
                child: Column(
                  children: [
                    SizedBox(
                      height: height / 20,
                    ),
                    Text(
                      moodstring,
                      style:
                          TextStyle(fontSize: width / 12, color: Colors.black),
                    ),
                    Image.asset(
                      img,
                      width: width / 1.5,
                      height: height / 6,
                    ),
                    SizedBox(
                      height: height / 25,
                    ),
                  ],
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(
                  '    Recommended quotes',
                  textAlign: TextAlign.left,
                  style: TextStyle(
                      fontSize: width / 15,
                      color: Colors.white,
                      fontWeight: FontWeight.w700),
                ),
              ],
            ),
            SizedBox(
              height: height / 50,
            ),
            SizedBox(
                // color: Colors.white,
                height: height / 4,
                child: ListView.builder(
                    itemCount: quote.length,
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (context, index) {
                      return Card(
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(
                            Radius.circular(16.0),
                          ),
                        ),
                        child: Image.asset(
                          quote[index]['image'],
                          fit: BoxFit.contain,
                          width: width / 1.4,
                          height: height / 6,
                        ),
                      );
                    })),
            SizedBox(
              height: height / 50,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(
                  '    Recommended songs',
                  textAlign: TextAlign.left,
                  style: TextStyle(
                      fontSize: width / 15,
                      color: Colors.white,
                      fontWeight: FontWeight.w700),
                ),
              ],
            ),
            SizedBox(
              height: height / 50,
            ),
            SizedBox(
                // color: Colors.white,
                height: height / 4,
                child: ListView.builder(
                    itemCount: songs.length,
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (context, index) {
                      return InkWell(
                        onTap: () {
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => AudioPlayerWidget(
                                        img: songs[index]['image'],
                                        url: songs[index]['url'],
                                      )));
                        },
                        child: Column(
                          children: [
                            Card(
                              shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.all(
                                  Radius.circular(16.0),
                                ),
                              ),
                              child: Image.asset(
                                songs[index]['image'],
                                fit: BoxFit.contain,
                                width: width / 1.4,
                                height: height / 5,
                              ),
                            ),
                            Text(songs[index]['name'].toString(),
                                style: TextStyle(
                                    fontSize: width / 18,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600)),
                          ],
                        ),
                      );
                    })),
          ],
        ),
      )),
      bottomNavigationBar: NavBar(
        index: 0,
      ),
    );
  }
}
