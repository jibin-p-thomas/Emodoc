import 'package:emodoc/class/moodscore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

import 'home-page.dart';

class ScorePage extends StatefulWidget {
  int score;
  int number;
  ScorePage({Key? key, required this.score, required this.number})
      : super(key: key);

  @override
  State<ScorePage> createState() => _ScorePageState();
}

class _ScorePageState extends State<ScorePage> {
  int moodscore = 0;
  String moodstring = "";
  String img = 'assets/images/smile.png';

  scorecal() {
    setState(() {
      moodscore = widget.score ~/ widget.number;
      if (moodscore == 4) {
        img = 'assets/images/smile.png';
        moodstring = "Happy !";
      } else if (moodscore == 3) {
        img = 'assets/images/netural.png';
        moodstring = "Normal !";
      } else if (moodscore == 2) {
        img = 'assets/images/sad.png';
        moodstring = "Sad !";
      } else if (moodscore == 1) {
        img = 'assets/images/angry.png';
        moodstring = "Angry !";
      }
    });
  }

  @override
  void initState() {
    scorecal();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: Text('Score'),
      ),
      body: Container(
        decoration: const BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
                colors: [Colors.purple, Colors.blue])),
        child: Column(
          children: [
            SizedBox(
              height: height / 5,
            ),
            Center(
              child: Card(
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(
                    Radius.circular(16.0),
                  ),
                ),
                child: Column(
                  children: [
                    SizedBox(
                      height: height / 12,
                    ),
                    Text(
                      moodstring,
                      style:
                          TextStyle(fontSize: width / 12, color: Colors.black),
                    ),
                    Image.asset(
                      img,
                      width: width / 1.5,
                      height: height / 6,
                    ),
                    SizedBox(
                      height: height / 12,
                    ),
                  ],
                ),
              ),
            ),
            ElevatedButton(
                onPressed: () async {
                  await MoodScore().moodScoreUpdate(moodscore, widget.number);
                  Navigator.pushReplacement(context,
                      MaterialPageRoute(builder: (context) => const Home()));
                },
                child: Text("Next")),
            SizedBox(
              height: height / 5,
            ),
            /*Center(
              child: Text(
                widget.score.toString(),
                style: TextStyle(fontSize: 20),
              ),
            ),
            Center(
              child: Text(
                widget.number.toString(),
                style: TextStyle(fontSize: 20),
              ),
            ),
            Center(
              child: Text(
                moodscore.toString(),
                style: TextStyle(fontSize: 20),
              ),
            ),
            Image.asset(
              img,
              width: width / 2,
              height: height / 8,
            ),*/
          ],
        ),
      ),
    );
  }
}
