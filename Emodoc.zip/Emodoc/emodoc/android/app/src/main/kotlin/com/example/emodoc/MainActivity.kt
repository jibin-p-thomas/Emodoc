package com.example.emodoc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
